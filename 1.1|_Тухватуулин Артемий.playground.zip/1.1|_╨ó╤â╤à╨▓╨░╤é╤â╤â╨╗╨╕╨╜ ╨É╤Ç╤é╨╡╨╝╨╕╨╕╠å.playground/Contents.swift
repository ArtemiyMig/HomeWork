//Пользователь вводит сумму вклада в банк и годовой процент.
//Найти сумму вклада через пять лет.

let summOfDep = Float(750000)
let proc = Float (4.7)
let dateOfMonth = Float(30)
let daysOfYears = Float(365)
// Формула для расчета дней хранения вклада
let Sum = (daysOfYears / 12) * dateOfMonth
// Формула расчета процента по вкладу за указанное пользователем
//Количество месяцев
let profit = (summOfDep * proc * (Sum / daysOfYears)) / 100
print(summOfDep + profit)
print("Процент по вкладу за", dateOfMonth, "Месяца(ев)", profit)
