// Решить квадратное уравнение
//ах^2 + bx + c = 0
//D=b^2-4ac=0
let a = 13
let b = 78
let c = -2
let AB = b * b
let AC = 4 * a * c
var dis = AB - AC
let radOne = (-b + dis) / 2
let radTwo = (-b - dis) / 2
let y = 2 * a
let radThree = -b / 2 * a
var resultOne = radOne / y
var resiltTwo = radTwo / y

if (dis > 0) {
    print("Решение имеет два корня","X1 =", radOne,"X2 =", radTwo)
} else if (dis < 0) {
    print("Решение корней не имеет")
} else if (dis == 0) {
    print("Решение имеет один корень","X =", radThree)
}
