//Даны катеты прямоугольного треугольника.
//Найти площадь, периметр и гипотенузу треугольника.

import Darwin

let catA = Double(3)
let catB = Double(9)
// Находим площадь треугольника
let yardage = (catA * catB) / 2
print("Площадь треугольника =", yardage)
//Находим гипотенузу прямоугольного треугольника
let gipForm = ((catA * catA) + (catB * catB))
let gip = sqrt(Double(gipForm))
print("Гипотенуза треугольника =", gip)
//Находим площадь треугольника
let per = catA + catB + gip
print("Периметр треугольника =", per)
